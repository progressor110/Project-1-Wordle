//
//  Constants.swift
//  Wordle
//
//  Created by Mari Batilando on 3/1/23.
//

import Foundation

let DELETE_KEY = "DEL"
